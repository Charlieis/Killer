# Copyright (C) @TheSmartBisnu
# Channel: https://t.me/itsSmartDev

# Pyrogram setup
API_ID = "123456"  # Replace this API ID with your actual API ID
API_HASH = "XXXXXXXXXXX"  # Replace this API HASH with your actual API HASH
SESSION_STRING = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"  # Replace this SESSION STRING with your actual SESSION_STRING
BOT_TOKEN = "12345678:XXXXXXXXXXXXXX"  # Replace this BOT_TOKEN

# Admin IDs
ADMIN_IDS = [12345678, 12345678]

# Limits
DEFAULT_LIMIT = 10000 # Card Scrapping Limit For Everyone
ADMIN_LIMIT = 50000 # Card Scrapping Limit For Admin
